/**
 * Created by Life on 2016-12-01.
 */
var app = angular.module('App',[]);

app.controller('AppCtrl',function($scope){

});