/**
 * Created by Life on 2016-12-15.
 */
angular.module('App').service('HueService',function(){
    var Hue;
    return{
        getRoomType : getRoomType
    }

    function getRoomType(data){

    }
})