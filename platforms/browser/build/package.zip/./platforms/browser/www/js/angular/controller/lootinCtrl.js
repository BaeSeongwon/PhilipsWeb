/**
 * Created by Life on 2016-12-14.
 */
angular.module('App').controller('lootinCtrl',function($scope){

});