/**
 * Created by Life on 2016-12-15.
 */
angular.module('App').controller('registCtrl',function($scope){

});