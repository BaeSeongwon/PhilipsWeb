/**
 * Created by Life on 2016-12-15.
 */
angular.module('App').value('IP','http:192.168.0.26:8888');
//http://ec2-52-78-41-172.ap-northeast-2.compute.amazonaws.com