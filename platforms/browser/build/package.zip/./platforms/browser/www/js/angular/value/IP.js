/**
 * Created by Life on 2016-12-15.
 */
angular.module('App').value('IP','http://192.168.0.26:8888');