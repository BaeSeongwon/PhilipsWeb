/**
 * Created by Life on 2016-12-16.
 */
angular.module('App').value('CPE_IP','http://cutesubini.iptime.org:70');