/**
 * Created by Life on 2016-12-16.
 */
angular.module('App').value('CPE_IP','http:192.168.0.23:3000');